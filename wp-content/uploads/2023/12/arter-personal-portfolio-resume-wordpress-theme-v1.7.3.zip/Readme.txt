Thank you for your recent purchase of "Arter - CV Resume WordPress Theme".

--------------------------------------

Theme Documentation: https://bslthemes.gitbook.io/arter-wp-doc/
Author: https://themeforest.net/user/bslthemes

--------------------------------------


Overview:

Arter – Resume WordPress Theme best suited for developers, designers, programmers, freelancers,
artists, coders, creators or any other digital professions. Modern and Creative theme design that
will help you create a web presence. Includes: Dark & Light versions, Unlimited colors, WooCommerce,
RTL support, One Page & Multi Page, Transitions page animations, Powerful Portfolio,
Elementor Page Builder – No coding skills needed, creating online resume and CV website
should no longer be a difficult.

--------------------------------------


Sourse & Credits:

- ACF Pro
- Elementor
- Bootstrap
- Font Awesome icons
- Anime.js
- Magnific Popup
- imagesLoaded
- Isotope
- Jarallax
- Swiper
- Swup
- Unsplash

--------------------------------------


IMPORTANT: Images used in the Preview demo are not included in the downloaded package.
